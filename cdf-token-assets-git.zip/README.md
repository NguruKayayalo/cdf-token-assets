# CDF Token Assets

Liste des tokens CDF pour intégration dans DODO/Uniswap/etc.